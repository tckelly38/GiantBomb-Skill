import requests
import datetime

mykey = "f84b8d0ddf3db0cb304c07a41c8e57fe980b7d28"
base_url = "http://www.giantbomb.com/api/videos"
params = dict(
    api_key=mykey,
    field_list="name,publish_date",
    format="json",
    limit="1"
)
headers = {
    'User-Agent': 'GiantBombSkill'
}


def lambda_handler(event, context):
    resp = requests.get(url=base_url, params=params, headers=headers).json()
    # {u'number_of_page_results': 1, u'status_code': 1, u'error': u'OK', u'results': [{u'publish_date': u'2017-06-16 00:57:00', u'name': u'Giant Bomb at Nite - Live From E3 2017: Nite 3'}], u'version': u'1.0', u'limit': 1, u'offset': 0, u'number_of_total_results': 11734}
    speech_text = "The last video uploaded was %s" % resp['results'][0]['name']
    return create_json_response(speech_text)

def create_json_response(speech_text):
    return {
        'version': "1.0",
        'response':
            {'outputSpeech':
                {'type': "PlainText",
                 'text': speech_text
                },
            'card':
                {'content': speech_text,
                'title': "Most Recent Video",
                'type': "Simple"
                },
            "reprompt":
                {'outputSpeech':
                    {'type':"PlainText",
                     'text':""
                    }
                },
            'shouldEndSession': "false"
            },
            'sessionAttributes': {}
        }

if __name__ == '__main__':
    app.run()
